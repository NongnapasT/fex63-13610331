<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-6 mt-4">
                <div class="card">
                    <div class="card-body">
                        <form action="/new" method="post">
                            <?php echo csrf_field(); ?>
                            <h1>Short URL</h1>
                            <hr>
                            <label for="" class="form-label">Paste Long URL</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" id="longUrl" name="longUrl" placeholder="verylongurl.com">
                                    <button class="btn btn-primary">Create Short URL</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
































<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\short-url-project\resources\views/new.blade.php ENDPATH**/ ?>