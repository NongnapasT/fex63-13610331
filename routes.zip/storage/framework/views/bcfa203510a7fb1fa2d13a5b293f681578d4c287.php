<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container-fluid">
            <div class="mt-5">
                <h1>Your Short URL</h1>
                <h5 >Quota Remaining <?php echo e(10-count($urls)); ?>/10</h5>
                <?php if($message = Session::get('success')): ?>
                    <p style="color: #0E9A00"><?php echo e($message); ?></p>
                <?php elseif($message = Session::get('delete')): ?>
                    <p style="color: red"><?php echo e($message); ?></p>
                <?php endif; ?>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Long URL</th>
                        <th>Short URL</th>
                        <th>Time</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(!$urls->isEmpty()): ?>
                        <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$Url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($index+1); ?></th>
                                <td><?php echo e($Url->LongUrl); ?></td>
                                <td><a target='_blank' href="/gt/<?php echo e($Url->ShortUrl); ?>">short.local/gt/<?php echo e($Url->ShortUrl); ?></a></td>
                                <td><?php echo e($Url->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\short-url-project\resources\views/index.blade.php ENDPATH**/ ?>