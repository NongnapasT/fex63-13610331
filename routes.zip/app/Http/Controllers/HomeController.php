<?php

namespace App\Http\Controllers;

use App\Url;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    //
}
